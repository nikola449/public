# Novuk Home Projects Website

## Scope
- Build a premium, mobile-responsive home page using the navy, slate, white, and metallic-gold brand direction.
- Add a full-width photographic opening banner with the “Your Home. Done Right.” message and two clear project actions.
- Add the requested trust badges and detailed service sections for fencing, concrete/driveways, and painting.
- Build a complete project-intake form with conditional fencing options, contact preference, property details, neighbor-sharing choice, photo upload, validation, and the 24-hour confirmation message. The form will remain inquiry-only and will not calculate prices.
- Add dedicated Fencing, Concrete & Driveways, Painting, About, and Contact pages so every navigation link opens a real, shareable page.
- Add a consistent header, mobile navigation, service-area footer, and unique page titles/descriptions.

## Visual direction
- Deep navy foundations, restrained slate surfaces, warm metallic-gold accents, and clean white content areas.
- Strong architectural typography, crisp edges, disciplined spacing, and subtle motion rather than decorative effects.
- Generate an original residential exterior image for the main banner and supporting project imagery where it materially improves the service presentation.

## Technical details
- Use the existing TanStack site structure and Tailwind design tokens.
- Keep all colors, fonts, shadows, and surface roles in the shared design system.
- Keep submissions in the current browser session only; no database, email delivery, or automated quote calculation is included.
- Verify the finished site at desktop and mobile sizes, including navigation, form behavior, and text/layout fit.
